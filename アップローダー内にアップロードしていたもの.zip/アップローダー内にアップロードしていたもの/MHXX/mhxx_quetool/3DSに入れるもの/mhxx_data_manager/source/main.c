/*
Copyright 2016 Seth VanHeulen

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <3ds.h>
#include "quest.h"
#include "save.h"
#include "ui.h"

int main(int argc, char* argv[]) {
    gfxInitDefault();
    ui_init();
    ui_menu_entry main_menu[] = {
        {"Export Quests", 1},
        {"Import Quests", 1},
        {"Delete Quests", 1},
        {"Backup Save", 1},
        {"Restore Save", 1},
    };
    while (aptMainLoop()) {
        int task = ui_menu("\x1b[32;1mMonster Hunter XX Data Manager (v1.0.0)\n\n\x1b[31;1mAlways keep a good backup of your save file!\x1b[0m\n\nSelect a task...", main_menu, 5);
        if (task == 0)
            export_quests();
        else if (task == 1)
            import_quests();
        else if (task == 2)
            delete_quests();
        else if (task == 3)
            backup_save();
        else if (task == 4)
            restore_save();
        else
            break;
    }
    gfxExit();
    return 0;
}

